import { useState, useEffect } from "react";
import { X } from "lucide-react";
import { Button } from "@/components/ui/button";

const ExitIntentPopup = () => {
  const [show, setShow] = useState(false);

  useEffect(() => {
    const handleMouseLeave = (e: MouseEvent) => {
      if (e.clientY <= 0 && !sessionStorage.getItem("exitPopupShown")) {
        setShow(true);
        sessionStorage.setItem("exitPopupShown", "true");
      }
    };

    document.addEventListener("mouseleave", handleMouseLeave);
    return () => document.removeEventListener("mouseleave", handleMouseLeave);
  }, []);

  if (!show) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-background/80 backdrop-blur-sm">
      <div className="relative bg-card border border-gold/30 rounded-lg p-8 max-w-md mx-4 text-center shadow-gold">
        <button
          onClick={() => setShow(false)}
          className="absolute top-3 right-3 text-muted-foreground hover:text-foreground"
        >
          <X className="w-5 h-5" />
        </button>

        <p className="text-gold font-body text-xs tracking-[0.3em] uppercase mb-2">Wait!</p>
        <h3 className="font-display text-2xl font-bold mb-3">Get 10% OFF</h3>
        <p className="text-muted-foreground font-body text-sm mb-6">
          Don't leave empty-handed! Use code <span className="text-gold font-semibold">SYEDS10</span> at checkout.
        </p>
        <Button variant="gold" size="lg" className="w-full" onClick={() => setShow(false)}>
          Claim My Discount
        </Button>
      </div>
    </div>
  );
};

export default ExitIntentPopup;
