import { useState } from "react";
import { products } from "@/data/products";
import ProductCard from "@/components/ProductCard";
import AnnouncementBar from "@/components/AnnouncementBar";
import Navbar from "@/components/Navbar";
import SiteFooter from "@/components/SiteFooter";
import WhatsAppButton from "@/components/WhatsAppButton";

const categories = ["All", "Gold Collection", "Black Collection", "Arabic Dial Collection", "Silver Collection"];

const CollectionsPage = () => {
  const [active, setActive] = useState("All");

  const filtered = active === "All" ? products : products.filter((p) => p.category === active);

  return (
    <div className="min-h-screen bg-background">
      <AnnouncementBar />
      <Navbar />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-10">
          <h1 className="font-display text-3xl sm:text-4xl font-bold mb-3">Our Collections</h1>
          <p className="text-muted-foreground font-body text-sm max-w-md mx-auto">
            Explore our curated selection of premium timepieces
          </p>
        </div>

        <div className="flex flex-wrap justify-center gap-3 mb-10">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setActive(cat)}
              className={`px-5 py-2 rounded-sm text-xs font-body font-medium tracking-wider uppercase transition-all duration-300 border ${
                active === cat
                  ? "bg-gradient-gold text-primary-foreground border-transparent"
                  : "bg-transparent text-muted-foreground border-border hover:border-gold/40 hover:text-foreground"
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {filtered.length === 0 ? (
          <p className="text-center text-muted-foreground font-body py-20">No products found in this collection.</p>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6">
            {filtered.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        )}
      </div>

      <SiteFooter />
      <WhatsAppButton />
    </div>
  );
};

export default CollectionsPage;
