import { useState } from "react";
import { ShoppingBag, Heart, Menu, X } from "lucide-react";
import { Link } from "react-router-dom";
import { useCart } from "@/contexts/CartContext";

const navItems = [
  { label: "Home", to: "/" },
  { label: "Collections", to: "/collections" },
];

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);
  const { itemCount, setIsCartOpen } = useCart();

  return (
    <nav className="sticky top-0 z-50 bg-background/95 backdrop-blur-md border-b border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <Link to="/" className="font-display text-2xl font-bold text-gradient-gold tracking-wider">
            SYEDS.STORE
          </Link>

          <div className="hidden md:flex items-center gap-8">
            {navItems.map((item) => (
              <Link
                key={item.label}
                to={item.to}
                className="text-sm font-body text-muted-foreground hover:text-gold transition-colors tracking-wide uppercase"
              >
                {item.label}
              </Link>
            ))}
          </div>

          <div className="flex items-center gap-4">
            <button className="text-muted-foreground hover:text-gold transition-colors">
              <Heart className="w-5 h-5" />
            </button>
            <button
              onClick={() => setIsCartOpen(true)}
              className="text-muted-foreground hover:text-gold transition-colors relative"
            >
              <ShoppingBag className="w-5 h-5" />
              {itemCount > 0 && (
                <span className="absolute -top-1 -right-1 w-4 h-4 bg-gold text-primary-foreground text-[10px] rounded-full flex items-center justify-center font-semibold">
                  {itemCount}
                </span>
              )}
            </button>
            <button className="md:hidden text-foreground" onClick={() => setIsOpen(!isOpen)}>
              {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {isOpen && (
        <div className="md:hidden bg-background border-t border-border">
          <div className="px-4 py-4 space-y-3">
            {navItems.map((item) => (
              <Link
                key={item.label}
                to={item.to}
                className="block text-sm font-body text-muted-foreground hover:text-gold transition-colors tracking-wide uppercase py-2"
                onClick={() => setIsOpen(false)}
              >
                {item.label}
              </Link>
            ))}
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;
