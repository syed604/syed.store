import { Truck, Award, Clock } from "lucide-react";

const announcements = [
  { icon: Truck, text: "Free Delivery All Over Pakistan" },
  { icon: Award, text: "1 Year Warranty" },
  { icon: Clock, text: "Cash on Delivery Available" },
];

const AnnouncementBar = () => {
  return (
    <div className="bg-gradient-gold py-2 overflow-hidden">
      <div className="flex items-center justify-center gap-8 md:gap-16 px-4">
        {announcements.map((item, i) => (
          <div key={i} className="flex items-center gap-2 text-primary-foreground">
            <item.icon className="w-3.5 h-3.5" />
            <span className="text-xs font-body font-medium tracking-wide whitespace-nowrap">{item.text}</span>
          </div>
        ))}
      </div>
    </div>
  );
};

export default AnnouncementBar;
