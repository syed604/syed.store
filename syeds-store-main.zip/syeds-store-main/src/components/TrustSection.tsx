import { Truck, Shield, Headphones } from "lucide-react";
import { useScrollAnimation } from "@/hooks/use-scroll-animation";

const trustItems = [
  { icon: Truck, title: "Free Delivery", desc: "All over Pakistan, no hidden charges" },
  { icon: Shield, title: "1 Year Warranty", desc: "Full warranty on every timepiece" },
  { icon: Headphones, title: "24/7 Support", desc: "WhatsApp & call support anytime" },
];

const TrustSection = () => {
  const { ref, isVisible } = useScrollAnimation();

  return (
    <section ref={ref} className="py-16 border-t border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-3 gap-6">
          {trustItems.map((item, i) => (
            <div
              key={i}
              className={`text-center transition-all duration-700 ${isVisible ? "opacity-100 translate-y-0 scale-100" : "opacity-0 translate-y-6 scale-95"}`}
              style={{ transitionDelay: isVisible ? `${i * 150}ms` : "0ms" }}
            >
              <div className="w-14 h-14 mx-auto mb-4 rounded-full border border-gold/30 flex items-center justify-center hover:scale-110 hover:border-gold transition-all duration-300">
                <item.icon className="w-6 h-6 text-gold" />
              </div>
              <h4 className="font-display text-sm font-semibold mb-1">{item.title}</h4>
              <p className="text-xs text-muted-foreground font-body">{item.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default TrustSection;
