import AnnouncementBar from "@/components/AnnouncementBar";
import Navbar from "@/components/Navbar";
import HeroSection from "@/components/HeroSection";
import FeaturedCollection from "@/components/FeaturedCollection";
import TrendingProducts from "@/components/TrendingProducts";
import BrandSection from "@/components/BrandSection";
import LifestyleBanners from "@/components/LifestyleBanners";
import Testimonials from "@/components/Testimonials";
import TrustSection from "@/components/TrustSection";
import SiteFooter from "@/components/SiteFooter";
import WhatsAppButton from "@/components/WhatsAppButton";
import ExitIntentPopup from "@/components/ExitIntentPopup";

const Index = () => {
  return (
    <div className="min-h-screen bg-background">
      <AnnouncementBar />
      <Navbar />
      <HeroSection />
      <FeaturedCollection />
      <BrandSection />
      <TrendingProducts />
      <LifestyleBanners />
      <Testimonials />
      <TrustSection />
      <SiteFooter />
      <WhatsAppButton />
      <ExitIntentPopup />
    </div>
  );
};

export default Index;
