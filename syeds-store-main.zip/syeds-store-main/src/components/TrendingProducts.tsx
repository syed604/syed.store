import ProductCard from "@/components/ProductCard";
import { products } from "@/data/products";
import { useScrollAnimation } from "@/hooks/use-scroll-animation";

const TrendingProducts = () => {
  const { ref, isVisible } = useScrollAnimation();
  const trending = products.filter((p) => p.badge);

  return (
    <section ref={ref} className="py-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
      <div className={`text-center mb-14 transition-all duration-700 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}`}>
        <p className="text-gold font-body text-xs tracking-[0.3em] uppercase mb-3">Most Popular</p>
        <h2 className="font-display text-3xl sm:text-4xl font-bold mb-4">Trending Now</h2>
        <div className="w-16 h-[2px] bg-gradient-gold mx-auto" />
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
        {trending.map((product, i) => (
          <div
            key={product.id}
            className={`transition-all duration-700 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"}`}
            style={{ transitionDelay: isVisible ? `${i * 100}ms` : "0ms" }}
          >
            <ProductCard product={product} />
          </div>
        ))}
      </div>
    </section>
  );
};

export default TrendingProducts;
