import { useState } from "react";
import { Link } from "react-router-dom";
import { ArrowLeft, Check, ShoppingBag, Truck, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useCart } from "@/contexts/CartContext";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import AnnouncementBar from "@/components/AnnouncementBar";
import Navbar from "@/components/Navbar";
import SiteFooter from "@/components/SiteFooter";

const CheckoutPage = () => {
  const { items, total, clearCart } = useCart();
  const { toast } = useToast();
  const [formData, setFormData] = useState({ name: "", phone: "", city: "", address: "" });
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const orderItems = items.map((item) => ({
        title: item.product.title,
        quantity: item.quantity,
        price: item.product.price,
      }));

      const { error } = await supabase.functions.invoke("send-order-email", {
        body: {
          name: formData.name,
          phone: formData.phone,
          city: formData.city,
          address: formData.address,
          items: orderItems,
          total,
        },
      });

      if (error) {
        console.error("Email error:", error);
        toast({ title: "Order placed!", description: "But we couldn't send the notification email. We'll follow up on WhatsApp." });
      }

      setSubmitted(true);
      clearCart();
    } catch (err) {
      console.error("Error:", err);
      toast({ title: "Order placed!", description: "We'll confirm via WhatsApp shortly." });
      setSubmitted(true);
      clearCart();
    } finally {
      setLoading(false);
    }
  };

  if (items.length === 0 && !submitted) {
    return (
      <div className="min-h-screen bg-background">
        <AnnouncementBar />
        <Navbar />
        <div className="max-w-2xl mx-auto px-4 py-20 text-center">
          <ShoppingBag className="w-16 h-16 mx-auto text-muted-foreground mb-4" />
          <h1 className="font-display text-2xl font-bold mb-3">Your cart is empty</h1>
          <Link to="/collections" className="text-gold hover:underline font-body text-sm">Browse Collections</Link>
        </div>
        <SiteFooter />
      </div>
    );
  }

  if (submitted) {
    return (
      <div className="min-h-screen bg-background">
        <AnnouncementBar />
        <Navbar />
        <div className="max-w-2xl mx-auto px-4 py-20 text-center">
          <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-gold/10 flex items-center justify-center">
            <Check className="w-8 h-8 text-gold" />
          </div>
          <h1 className="font-display text-2xl font-bold mb-2">Order Placed Successfully!</h1>
          <p className="text-muted-foreground font-body text-sm mb-6">We'll confirm your order via WhatsApp shortly.</p>
          <Link to="/">
            <Button variant="gold">Continue Shopping</Button>
          </Link>
        </div>
        <SiteFooter />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <AnnouncementBar />
      <Navbar />

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Link to="/" className="inline-flex items-center gap-2 text-muted-foreground hover:text-gold transition-colors text-sm font-body mb-8">
          <ArrowLeft className="w-4 h-4" /> Back to Shop
        </Link>

        <h1 className="font-display text-3xl font-bold mb-8">Checkout</h1>

        <div className="grid md:grid-cols-5 gap-8">
          {/* Order Summary */}
          <div className="md:col-span-2 order-2 md:order-1">
            <div className="bg-card border border-border rounded-lg p-5 sticky top-24">
              <h3 className="font-display text-sm font-semibold mb-4">Order Summary</h3>
              <div className="space-y-3 mb-4">
                {items.map((item) => (
                  <div key={item.product.id} className="flex gap-3">
                    <img src={item.product.image} alt={item.product.title} className="w-14 h-14 object-cover rounded" />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-body font-medium truncate">{item.product.title}</p>
                      <p className="text-xs text-muted-foreground font-body">Qty: {item.quantity}</p>
                    </div>
                    <p className="text-sm font-body font-bold text-gold">Rs. {(item.product.price * item.quantity).toLocaleString()}</p>
                  </div>
                ))}
              </div>
              <div className="border-t border-border pt-3 space-y-2">
                <div className="flex justify-between text-sm font-body">
                  <span className="text-muted-foreground">Subtotal</span>
                  <span>Rs. {total.toLocaleString()}</span>
                </div>
                <div className="flex justify-between text-sm font-body">
                  <span className="text-muted-foreground">Delivery</span>
                  <span className="text-gold">FREE</span>
                </div>
                <div className="flex justify-between font-body font-bold border-t border-border pt-2">
                  <span>Total</span>
                  <span className="text-gold">Rs. {total.toLocaleString()}</span>
                </div>
              </div>
            </div>
          </div>

          {/* COD Form */}
          <div className="md:col-span-3 order-1 md:order-2">
            <div className="bg-card border border-border rounded-lg p-6">
              <div className="flex items-center gap-2 mb-1">
                <Truck className="w-5 h-5 text-gold" />
                <h3 className="font-display text-lg font-semibold">Cash on Delivery</h3>
              </div>
              <p className="text-xs text-muted-foreground font-body mb-6">Pay when you receive your order — Free delivery all over Pakistan</p>

              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="block text-xs font-body font-medium text-muted-foreground mb-1">Full Name</label>
                  <input
                    type="text"
                    required
                    placeholder="Muhammad Ahmed"
                    className="w-full bg-background border border-border rounded px-4 py-2.5 text-sm font-body text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-gold"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  />
                </div>
                <div>
                  <label className="block text-xs font-body font-medium text-muted-foreground mb-1">Phone Number</label>
                  <input
                    type="tel"
                    required
                    placeholder="03XX-XXXXXXX"
                    className="w-full bg-background border border-border rounded px-4 py-2.5 text-sm font-body text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-gold"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  />
                </div>
                <div>
                  <label className="block text-xs font-body font-medium text-muted-foreground mb-1">City</label>
                  <input
                    type="text"
                    required
                    placeholder="Lahore"
                    className="w-full bg-background border border-border rounded px-4 py-2.5 text-sm font-body text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-gold"
                    value={formData.city}
                    onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                  />
                </div>
                <div>
                  <label className="block text-xs font-body font-medium text-muted-foreground mb-1">Full Address</label>
                  <textarea
                    required
                    rows={3}
                    placeholder="House #, Street, Area"
                    className="w-full bg-background border border-border rounded px-4 py-2.5 text-sm font-body text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-gold resize-none"
                    value={formData.address}
                    onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                  />
                </div>
                <Button type="submit" variant="gold" size="lg" className="w-full py-6 text-sm" disabled={loading}>
                  {loading ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <ShoppingBag className="w-4 h-4 mr-2" />}
                  {loading ? "Placing Order..." : `Place Order — Rs. ${total.toLocaleString()}`}
                </Button>
              </form>
            </div>
          </div>
        </div>
      </div>

      <SiteFooter />
    </div>
  );
};

export default CheckoutPage;
