import { Star } from "lucide-react";
import { useScrollAnimation } from "@/hooks/use-scroll-animation";

const testimonials = [
  { name: "Ahmed Raza", city: "Karachi", text: "Watch bilkul same thi jesi pic mein thi. Highly recommended! Quality zabardast hai.", rating: 5 },
  { name: "Usman Ali", city: "Lahore", text: "Maine apne bhai ko gift di, bohot khush hua. Premium packaging aur fast delivery. 10/10!", rating: 5 },
  { name: "Hassan Sheikh", city: "Islamabad", text: "Best watches at this price range. I've ordered 3 times now. COD is a huge plus!", rating: 5 },
  { name: "Bilal Khan", city: "Rawalpindi", text: "Pehle doubt tha online se lene mein, but Syeds.store ne trust bana diya. Superb quality!", rating: 5 },
];

const Testimonials = () => {
  const { ref, isVisible } = useScrollAnimation();

  return (
    <section ref={ref} className="py-20 bg-card">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className={`text-center mb-14 transition-all duration-700 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}`}>
          <p className="text-gold font-body text-xs tracking-[0.3em] uppercase mb-3">Customer Love</p>
          <h2 className="font-display text-3xl sm:text-4xl font-bold mb-4">What Our Customers Say</h2>
          <div className="w-16 h-[2px] bg-gradient-gold mx-auto" />
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {testimonials.map((t, i) => (
            <div
              key={i}
              className={`bg-background border border-border rounded-lg p-6 hover:border-gold/30 hover:scale-[1.02] transition-all duration-500 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"}`}
              style={{ transitionDelay: isVisible ? `${i * 120}ms` : "0ms" }}
            >
              <div className="flex gap-1 mb-3">
                {Array.from({ length: t.rating }).map((_, j) => (
                  <Star key={j} className="w-4 h-4 fill-gold text-gold" />
                ))}
              </div>
              <p className="text-sm text-muted-foreground font-body leading-relaxed mb-4">"{t.text}"</p>
              <div>
                <p className="text-sm font-semibold font-body">{t.name}</p>
                <p className="text-xs text-muted-foreground font-body">{t.city}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;
