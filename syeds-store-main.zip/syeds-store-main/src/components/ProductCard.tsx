import { Heart, ShoppingBag } from "lucide-react";
import { Link } from "react-router-dom";
import { useCart } from "@/contexts/CartContext";
import type { Product } from "@/data/products";

interface ProductCardProps {
  product: Product;
}

const ProductCard = ({ product }: ProductCardProps) => {
  const { addToCart } = useCart();
  const discount = Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100);

  return (
    <div className="group relative bg-card border border-border rounded-lg overflow-hidden hover:border-gold/30 transition-all duration-500">
      {product.badge && (
        <span className="absolute top-3 left-3 z-10 bg-gradient-gold text-primary-foreground text-[10px] font-body font-semibold tracking-wider uppercase px-3 py-1 rounded-sm">
          {product.badge}
        </span>
      )}

      <button className="absolute top-3 right-3 z-10 w-8 h-8 rounded-full bg-background/80 backdrop-blur flex items-center justify-center text-muted-foreground hover:text-gold transition-colors">
        <Heart className="w-4 h-4" />
      </button>

      <Link to={`/product/${product.id}`}>
        <div className="aspect-square overflow-hidden bg-secondary">
          <img
            src={product.image}
            alt={product.title}
            className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
            loading="lazy"
            width={800}
            height={800}
          />
        </div>
      </Link>

      <div className="p-4">
        <p className="text-[10px] text-muted-foreground font-body tracking-wider uppercase mb-1">
          {product.category}
        </p>
        <Link to={`/product/${product.id}`}>
          <h3 className="font-display text-base font-semibold mb-2 hover:text-gold transition-colors">
            {product.title}
          </h3>
        </Link>
        <div className="flex items-center gap-2 mb-3">
          <span className="text-gold font-body font-bold text-lg">Rs. {product.price.toLocaleString()}</span>
          <span className="text-muted-foreground text-sm line-through">Rs. {product.originalPrice.toLocaleString()}</span>
          <span className="text-xs bg-gold/10 text-gold px-2 py-0.5 rounded font-medium">-{discount}%</span>
        </div>
        <button
          onClick={() => addToCart(product)}
          className="w-full flex items-center justify-center gap-2 bg-secondary hover:bg-gold hover:text-primary-foreground text-secondary-foreground py-2.5 rounded text-xs font-body font-medium tracking-wider uppercase transition-all duration-300"
        >
          <ShoppingBag className="w-3.5 h-3.5" />
          Add to Cart
        </button>
      </div>
    </div>
  );
};

export default ProductCard;
