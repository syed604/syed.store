import { useScrollAnimation } from "@/hooks/use-scroll-animation";

const brands = ["ROLEX", "PATEK PHILIPPE", "TISSOT", "OMEGA", "TAG HEUER"];

const BrandSection = () => {
  const { ref, isVisible } = useScrollAnimation();

  return (
    <section ref={ref} className="py-16 border-y border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <p className={`text-muted-foreground font-body text-xs tracking-[0.3em] uppercase mb-10 transition-all duration-700 ${isVisible ? "opacity-100" : "opacity-0"}`}>
          Inspired by World-Class Craftsmanship
        </p>
        <div className="flex flex-wrap items-center justify-center gap-8 md:gap-16">
          {brands.map((brand, i) => (
            <span
              key={brand}
              className={`font-display text-lg md:text-xl text-muted-foreground/40 tracking-[0.15em] hover:text-gold/60 hover:scale-110 transition-all duration-500 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"}`}
              style={{ transitionDelay: isVisible ? `${i * 100}ms` : "0ms" }}
            >
              {brand}
            </span>
          ))}
        </div>
      </div>
    </section>
  );
};

export default BrandSection;
