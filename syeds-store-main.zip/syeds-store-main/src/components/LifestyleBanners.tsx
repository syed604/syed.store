import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { useScrollAnimation } from "@/hooks/use-scroll-animation";
import blackCollection from "@/assets/black-collection.jpg";
import arabicCollection from "@/assets/arabic-collection.jpg";

const LifestyleBanners = () => {
  const { ref, isVisible } = useScrollAnimation();

  return (
    <section ref={ref} className="py-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
      <div className="grid md:grid-cols-2 gap-6">
        <div
          className={`relative h-80 md:h-96 rounded-lg overflow-hidden group transition-all duration-700 ${isVisible ? "opacity-100 translate-x-0" : "opacity-0 -translate-x-10"}`}
        >
          <img src={blackCollection} alt="Black Collection" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" loading="lazy" width={1200} height={600} />
          <div className="absolute inset-0 bg-background/50 flex flex-col items-center justify-center text-center p-6">
            <p className="text-gold font-body text-xs tracking-[0.3em] uppercase mb-2">Exclusive</p>
            <h3 className="font-display text-3xl font-bold mb-4">Black Collection</h3>
            <Link to="/collections">
              <Button variant="goldOutline" size="lg">Explore</Button>
            </Link>
          </div>
        </div>

        <div
          className={`relative h-80 md:h-96 rounded-lg overflow-hidden group transition-all duration-700 ${isVisible ? "opacity-100 translate-x-0" : "opacity-0 translate-x-10"}`}
          style={{ transitionDelay: isVisible ? "150ms" : "0ms" }}
        >
          <img src={arabicCollection} alt="Arabic Dial Collection" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" loading="lazy" width={1200} height={600} />
          <div className="absolute inset-0 bg-background/50 flex flex-col items-center justify-center text-center p-6">
            <p className="text-gold font-body text-xs tracking-[0.3em] uppercase mb-2">Heritage</p>
            <h3 className="font-display text-3xl font-bold mb-4">Arabic Dial Collection</h3>
            <Link to="/collections">
              <Button variant="goldOutline" size="lg">Discover</Button>
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
};

export default LifestyleBanners;
