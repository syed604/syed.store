import { serve } from "https://deno.land/std@0.190.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

interface OrderDetails {
  name: string;
  phone: string;
  city: string;
  address: string;
  items: Array<{
    title: string;
    quantity: number;
    price: number;
  }>;
  total: number;
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const RESEND_API_KEY = Deno.env.get("RESEND_API_KEY");
    if (!RESEND_API_KEY) {
      throw new Error("RESEND_API_KEY is not set");
    }

    const order: OrderDetails = await req.json();

    const itemsHtml = order.items
      .map(
        (item) =>
          `<tr>
            <td style="padding:8px 12px;border-bottom:1px solid #eee;">${item.title}</td>
            <td style="padding:8px 12px;border-bottom:1px solid #eee;text-align:center;">${item.quantity}</td>
            <td style="padding:8px 12px;border-bottom:1px solid #eee;text-align:right;">Rs. ${(item.price * item.quantity).toLocaleString()}</td>
          </tr>`
      )
      .join("");

    const html = `
      <div style="font-family:Arial,sans-serif;max-width:600px;margin:0 auto;background:#fff;border:1px solid #e5e5e5;border-radius:8px;overflow:hidden;">
        <div style="background:#1a1a1a;padding:20px 24px;">
          <h1 style="color:#d4af37;margin:0;font-size:20px;">🛒 New Order — Syeds.store</h1>
        </div>
        <div style="padding:24px;">
          <h2 style="font-size:16px;margin:0 0 16px;color:#333;">Customer Details</h2>
          <table style="width:100%;border-collapse:collapse;margin-bottom:24px;">
            <tr><td style="padding:6px 0;color:#666;width:100px;">Name:</td><td style="padding:6px 0;font-weight:bold;">${order.name}</td></tr>
            <tr><td style="padding:6px 0;color:#666;">Phone:</td><td style="padding:6px 0;font-weight:bold;">${order.phone}</td></tr>
            <tr><td style="padding:6px 0;color:#666;">City:</td><td style="padding:6px 0;font-weight:bold;">${order.city}</td></tr>
            <tr><td style="padding:6px 0;color:#666;">Address:</td><td style="padding:6px 0;font-weight:bold;">${order.address}</td></tr>
          </table>
          <h2 style="font-size:16px;margin:0 0 12px;color:#333;">Order Items</h2>
          <table style="width:100%;border-collapse:collapse;margin-bottom:16px;">
            <thead>
              <tr style="background:#f9f9f9;">
                <th style="padding:8px 12px;text-align:left;font-size:13px;color:#666;">Product</th>
                <th style="padding:8px 12px;text-align:center;font-size:13px;color:#666;">Qty</th>
                <th style="padding:8px 12px;text-align:right;font-size:13px;color:#666;">Price</th>
              </tr>
            </thead>
            <tbody>${itemsHtml}</tbody>
          </table>
          <div style="background:#1a1a1a;color:#d4af37;padding:12px 16px;border-radius:6px;font-size:18px;font-weight:bold;text-align:right;">
            Total: Rs. ${order.total.toLocaleString()}
          </div>
          <p style="margin:16px 0 0;font-size:12px;color:#999;">Payment: Cash on Delivery</p>
        </div>
      </div>
    `;

    const res = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${RESEND_API_KEY}`,
      },
      body: JSON.stringify({
        from: "Syeds.store Orders <onboarding@resend.dev>",
        to: ["syedarman1121@gmail.com"],
        subject: `New Order from ${order.name} — Rs. ${order.total.toLocaleString()}`,
        html,
      }),
    });

    const data = await res.json();

    if (!res.ok) {
      console.error("Resend error:", data);
      return new Response(JSON.stringify({ error: data }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    return new Response(JSON.stringify({ success: true, id: data.id }), {
      status: 200,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (error) {
    console.error("Error:", error);
    return new Response(JSON.stringify({ error: error.message }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
