import { X, Minus, Plus, ShoppingBag } from "lucide-react";
import { Link } from "react-router-dom";
import { useCart } from "@/contexts/CartContext";
import { Button } from "@/components/ui/button";

const CartDrawer = () => {
  const { items, removeFromCart, updateQuantity, total, itemCount, isCartOpen, setIsCartOpen } = useCart();

  if (!isCartOpen) return null;

  return (
    <>
      <div className="fixed inset-0 bg-background/60 backdrop-blur-sm z-50 animate-[fade-in_0.2s_ease-out]" onClick={() => setIsCartOpen(false)} />
      <div className="fixed right-0 top-0 h-full w-full max-w-md bg-card border-l border-border z-50 flex flex-col animate-[slide-in-right_0.3s_ease-out]">
        <div className="flex items-center justify-between p-6 border-b border-border">
          <h2 className="font-display text-lg font-semibold">Your Cart ({itemCount})</h2>
          <button onClick={() => setIsCartOpen(false)} className="text-muted-foreground hover:text-foreground transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        {items.length === 0 ? (
          <div className="flex-1 flex flex-col items-center justify-center gap-4 text-center p-6 animate-[fade-in_0.3s_ease-out]">
            <ShoppingBag className="w-12 h-12 text-muted-foreground" />
            <p className="font-body text-muted-foreground">Your cart is empty</p>
            <Button variant="gold" onClick={() => setIsCartOpen(false)}>Continue Shopping</Button>
          </div>
        ) : (
          <>
            <div className="flex-1 overflow-y-auto p-6 space-y-4">
              {items.map((item, i) => (
                <div
                  key={item.product.id}
                  className="flex gap-4 bg-secondary/50 rounded-lg p-3 animate-[fade-in_0.3s_ease-out]"
                  style={{ animationDelay: `${i * 50}ms`, animationFillMode: "both" }}
                >
                  <img src={item.product.image} alt={item.product.title} className="w-20 h-20 object-cover rounded" />
                  <div className="flex-1 min-w-0">
                    <h4 className="font-display text-sm font-semibold truncate">{item.product.title}</h4>
                    <p className="text-gold font-body text-sm font-bold">Rs. {item.product.price.toLocaleString()}</p>
                    <div className="flex items-center gap-2 mt-2">
                      <button
                        onClick={() => updateQuantity(item.product.id, item.quantity - 1)}
                        className="w-6 h-6 rounded bg-muted flex items-center justify-center text-muted-foreground hover:text-foreground transition-colors"
                      >
                        <Minus className="w-3 h-3" />
                      </button>
                      <span className="text-sm font-body w-6 text-center">{item.quantity}</span>
                      <button
                        onClick={() => updateQuantity(item.product.id, item.quantity + 1)}
                        className="w-6 h-6 rounded bg-muted flex items-center justify-center text-muted-foreground hover:text-foreground transition-colors"
                      >
                        <Plus className="w-3 h-3" />
                      </button>
                      <button
                        onClick={() => removeFromCart(item.product.id)}
                        className="ml-auto text-xs text-muted-foreground hover:text-destructive font-body transition-colors"
                      >
                        Remove
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="border-t border-border p-6 space-y-4">
              <div className="flex justify-between font-body">
                <span className="text-muted-foreground">Subtotal</span>
                <span className="font-bold text-gold">Rs. {total.toLocaleString()}</span>
              </div>
              <p className="text-xs text-muted-foreground font-body">Free delivery all over Pakistan</p>
              <Link to="/checkout" onClick={() => setIsCartOpen(false)}>
                <Button variant="gold" size="lg" className="w-full py-6 text-sm">
                  Proceed to Checkout
                </Button>
              </Link>
            </div>
          </>
        )}
      </div>
    </>
  );
};

export default CartDrawer;
