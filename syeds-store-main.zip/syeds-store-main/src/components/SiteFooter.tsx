import { Link } from "react-router-dom";
import { Instagram, Facebook, MessageCircle } from "lucide-react";

const Footer = () => {
  return (
    <footer className="bg-card border-t border-border pt-16 pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-12">
          <div className="col-span-2 md:col-span-1">
            <h3 className="font-display text-xl font-bold text-gradient-gold mb-4">SYEDS.STORE</h3>
            <p className="text-sm text-muted-foreground font-body leading-relaxed">
              Pakistan's premium destination for luxury timepieces. Style meets affordability.
            </p>
          </div>

          <div>
            <h4 className="font-display text-sm font-semibold mb-4 text-gold">Quick Links</h4>
            <ul className="space-y-2">
              {["Home", "Shop", "Collections", "About Us"].map((item) => (
                <li key={item}>
                  <Link to="/" className="text-sm text-muted-foreground hover:text-gold transition-colors font-body">
                    {item}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="font-display text-sm font-semibold mb-4 text-gold">Policies</h4>
            <ul className="space-y-2">
              {["Refund Policy", "Shipping Policy", "Privacy Policy", "Terms of Service"].map((item) => (
                <li key={item}>
                  <Link to="/" className="text-sm text-muted-foreground hover:text-gold transition-colors font-body">
                    {item}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="font-display text-sm font-semibold mb-4 text-gold">Contact</h4>
            <ul className="space-y-2 text-sm text-muted-foreground font-body">
              <li>WhatsApp: +92 300 1234567</li>
              <li>Email: info@syeds.store</li>
              <li>Mon–Sat: 10AM – 10PM</li>
            </ul>
            <div className="flex gap-3 mt-4">
              <a href="#" className="text-muted-foreground hover:text-gold transition-colors">
                <Instagram className="w-5 h-5" />
              </a>
              <a href="#" className="text-muted-foreground hover:text-gold transition-colors">
                <Facebook className="w-5 h-5" />
              </a>
              <a href="#" className="text-muted-foreground hover:text-gold transition-colors">
                <MessageCircle className="w-5 h-5" />
              </a>
            </div>
          </div>
        </div>

        <div className="border-t border-border pt-6 text-center">
          <p className="text-xs text-muted-foreground font-body">
            © 2026 Syeds.store. All rights reserved. Premium watches for Pakistan.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
