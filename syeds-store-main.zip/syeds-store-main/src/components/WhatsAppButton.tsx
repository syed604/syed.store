import { MessageCircle } from "lucide-react";

const WhatsAppButton = () => {
  return (
    <a
      href="https://wa.me/923001234567?text=Hi%20Syeds.store!%20I%27m%20interested%20in%20your%20watches."
      target="_blank"
      rel="noopener noreferrer"
      className="fixed bottom-6 right-6 z-50 w-14 h-14 bg-[#25D366] rounded-full flex items-center justify-center shadow-lg hover:scale-110 transition-transform animate-pulse-gold"
      aria-label="Chat on WhatsApp"
    >
      <MessageCircle className="w-7 h-7 text-foreground fill-foreground" style={{ color: 'white', fill: 'white' }} />
    </a>
  );
};

export default WhatsAppButton;
