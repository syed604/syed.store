import { useParams, Link } from "react-router-dom";
import { useState } from "react";
import { ArrowLeft, Star, ShoppingBag, Truck, Shield, Check, Minus, Plus } from "lucide-react";
import { useCart } from "@/contexts/CartContext";
import { Button } from "@/components/ui/button";
import { products } from "@/data/products";
import AnnouncementBar from "@/components/AnnouncementBar";
import Navbar from "@/components/Navbar";
import SiteFooter from "@/components/SiteFooter";
import WhatsAppButton from "@/components/WhatsAppButton";

const ProductPage = () => {
  const { id } = useParams();
  const product = products.find((p) => p.id === id);
  const { addToCart } = useCart();
  const [qty, setQty] = useState(1);
  const [formData, setFormData] = useState({ name: "", phone: "", address: "", city: "" });
  const [submitted, setSubmitted] = useState(false);

  if (!product) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <h1 className="font-display text-2xl mb-4">Product not found</h1>
          <Link to="/" className="text-gold hover:underline">Go back home</Link>
        </div>
      </div>
    );
  }

  const discount = Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  return (
    <div className="min-h-screen bg-background">
      <AnnouncementBar />
      <Navbar />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Link to="/" className="inline-flex items-center gap-2 text-muted-foreground hover:text-gold transition-colors text-sm font-body mb-8">
          <ArrowLeft className="w-4 h-4" /> Back to Shop
        </Link>

        <div className="grid md:grid-cols-2 gap-10">
          {/* Image */}
          <div className="aspect-square rounded-lg overflow-hidden bg-card border border-border">
            <img src={product.image} alt={product.title} className="w-full h-full object-cover" width={800} height={800} />
          </div>

          {/* Details */}
          <div>
            {product.badge && (
              <span className="inline-block bg-gradient-gold text-primary-foreground text-[10px] font-body font-semibold tracking-wider uppercase px-3 py-1 rounded-sm mb-4">
                {product.badge}
              </span>
            )}

            <p className="text-muted-foreground font-body text-xs tracking-wider uppercase mb-2">{product.category}</p>
            <h1 className="font-display text-3xl sm:text-4xl font-bold mb-4">{product.title}</h1>

            <div className="flex items-center gap-3 mb-2">
              <span className="text-gold font-body font-bold text-2xl">Rs. {product.price.toLocaleString()}</span>
              <span className="text-muted-foreground text-lg line-through">Rs. {product.originalPrice.toLocaleString()}</span>
              <span className="bg-gold/10 text-gold px-3 py-1 rounded text-sm font-medium">-{discount}%</span>
            </div>

            <p className="text-destructive text-sm font-body font-medium mb-6">
              🔥 Only {product.stock} left in stock — order now!
            </p>

            <div className="flex gap-1 mb-4">
              {Array.from({ length: 5 }).map((_, i) => (
                <Star key={i} className="w-4 h-4 fill-gold text-gold" />
              ))}
              <span className="text-sm text-muted-foreground ml-2 font-body">(127 reviews)</span>
            </div>

            <p className="text-muted-foreground font-body text-sm leading-relaxed mb-6">{product.description}</p>

            {/* Features */}
            <div className="mb-8">
              <h3 className="font-display text-sm font-semibold mb-3">Features</h3>
              <div className="grid grid-cols-2 gap-2">
                {product.features.map((f, i) => (
                  <div key={i} className="flex items-center gap-2 text-sm text-muted-foreground font-body">
                    <Check className="w-3.5 h-3.5 text-gold" /> {f}
                  </div>
                ))}
              </div>
            </div>

            {/* Add to Cart */}
            <div className="flex items-center gap-3 mb-6">
              <div className="flex items-center border border-border rounded">
                <button onClick={() => setQty(Math.max(1, qty - 1))} className="w-10 h-10 flex items-center justify-center text-muted-foreground hover:text-foreground">
                  <Minus className="w-4 h-4" />
                </button>
                <span className="w-10 text-center font-body text-sm">{qty}</span>
                <button onClick={() => setQty(qty + 1)} className="w-10 h-10 flex items-center justify-center text-muted-foreground hover:text-foreground">
                  <Plus className="w-4 h-4" />
                </button>
              </div>
              <button
                onClick={() => addToCart(product, qty)}
                className="flex-1 flex items-center justify-center gap-2 bg-gradient-gold text-primary-foreground py-3 rounded text-xs font-body font-semibold tracking-wider uppercase hover:shadow-gold transition-all duration-300"
              >
                <ShoppingBag className="w-4 h-4" />
                Add to Cart
              </button>
            </div>

            {/* Trust badges */}
            <div className="flex gap-6 mb-8 py-4 border-y border-border">
              <div className="flex items-center gap-2 text-xs text-muted-foreground font-body">
                <Truck className="w-4 h-4 text-gold" /> Free Delivery
              </div>
              <div className="flex items-center gap-2 text-xs text-muted-foreground font-body">
                <Shield className="w-4 h-4 text-gold" /> 1 Year Warranty
              </div>
            </div>

            {/* COD Form */}
            <div className="bg-card border border-border rounded-lg p-6">
              <h3 className="font-display text-lg font-semibold mb-1">Order via Cash on Delivery</h3>
              <p className="text-xs text-muted-foreground font-body mb-4">Pay when you receive your watch</p>

              {submitted ? (
                <div className="text-center py-6">
                  <div className="w-12 h-12 mx-auto mb-3 rounded-full bg-gold/10 flex items-center justify-center">
                    <Check className="w-6 h-6 text-gold" />
                  </div>
                  <h4 className="font-display text-lg font-semibold mb-1">Order Placed!</h4>
                  <p className="text-sm text-muted-foreground font-body">We'll confirm via WhatsApp shortly.</p>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-3">
                  <input
                    type="text"
                    placeholder="Full Name"
                    required
                    className="w-full bg-background border border-border rounded px-4 py-2.5 text-sm font-body text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-gold"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  />
                  <input
                    type="tel"
                    placeholder="Phone Number (03XX-XXXXXXX)"
                    required
                    className="w-full bg-background border border-border rounded px-4 py-2.5 text-sm font-body text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-gold"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  />
                  <input
                    type="text"
                    placeholder="City"
                    required
                    className="w-full bg-background border border-border rounded px-4 py-2.5 text-sm font-body text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-gold"
                    value={formData.city}
                    onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                  />
                  <textarea
                    placeholder="Full Address"
                    required
                    rows={2}
                    className="w-full bg-background border border-border rounded px-4 py-2.5 text-sm font-body text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-gold resize-none"
                    value={formData.address}
                    onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                  />
                  <Button type="submit" variant="gold" size="lg" className="w-full py-6 text-sm">
                    <ShoppingBag className="w-4 h-4 mr-2" />
                    Place Order — Rs. {product.price.toLocaleString()}
                  </Button>
                </form>
              )}
            </div>
          </div>
        </div>
      </div>

      <SiteFooter />
      <WhatsAppButton />
    </div>
  );
};

export default ProductPage;
