import watch1 from "@/assets/watch-1.jpg";
import watch2 from "@/assets/watch-2.jpg";
import watch3 from "@/assets/watch-3.jpg";
import watch4 from "@/assets/watch-4.jpg";
import watch5 from "@/assets/watch-5.jpg";
import watch6 from "@/assets/watch-6.jpg";

export interface Product {
  id: string;
  title: string;
  price: number;
  originalPrice: number;
  image: string;
  category: string;
  badge?: string;
  stock: number;
  description: string;
  features: string[];
}

export const products: Product[] = [
  {
    id: "royal-gold-chronograph",
    title: "Royal Gold Chronograph",
    price: 4999,
    originalPrice: 8999,
    image: watch1,
    category: "Gold Collection",
    badge: "Best Seller",
    stock: 5,
    description: "A stunning gold chronograph that commands attention. Crafted with precision and finished with a luxurious gold plating that stands the test of time.",
    features: ["Stainless Steel Body", "Gold PVD Coating", "Chronograph Movement", "Water Resistant 30M", "Scratch-Resistant Glass", "1 Year Warranty"],
  },
  {
    id: "silver-elite-classic",
    title: "Silver Elite Classic",
    price: 3999,
    originalPrice: 6999,
    image: watch2,
    category: "Silver Collection",
    badge: "New Arrival",
    stock: 8,
    description: "Timeless elegance meets modern precision. The Silver Elite Classic is the perfect dress watch for the discerning gentleman.",
    features: ["316L Stainless Steel", "Sapphire Crystal Glass", "Japanese Quartz Movement", "Water Resistant 50M", "Premium Finish", "1 Year Warranty"],
  },
  {
    id: "noir-leather-prestige",
    title: "Noir Leather Prestige",
    price: 3499,
    originalPrice: 5999,
    image: watch3,
    category: "Black Collection",
    stock: 3,
    description: "The Noir Leather Prestige embodies sophistication with its sleek black dial and genuine leather strap.",
    features: ["Genuine Leather Strap", "Black Ion Plating", "Miyota Movement", "Water Resistant 30M", "Anti-Reflective Coating", "1 Year Warranty"],
  },
  {
    id: "arabic-rose-gold",
    title: "Arabic Dial Rose Gold",
    price: 5499,
    originalPrice: 9999,
    image: watch4,
    category: "Arabic Dial Collection",
    badge: "Limited Edition",
    stock: 2,
    description: "Exquisite Arabic numerals meet rose gold luxury. A statement piece that celebrates heritage and craftsmanship.",
    features: ["Rose Gold PVD Coating", "Arabic Numeral Dial", "Automatic Movement", "Water Resistant 50M", "Exhibition Caseback", "1 Year Warranty"],
  },
  {
    id: "dual-tone-navigator",
    title: "Dual Tone Navigator",
    price: 4499,
    originalPrice: 7999,
    image: watch5,
    category: "Gold Collection",
    badge: "Trending",
    stock: 6,
    description: "The perfect blend of gold and silver, the Dual Tone Navigator is versatile enough for any occasion.",
    features: ["Two-Tone Stainless Steel", "Chronograph Function", "Date Display", "Water Resistant 100M", "Luminous Hands", "1 Year Warranty"],
  },
  {
    id: "executive-black-gold",
    title: "Executive Black & Gold",
    price: 4799,
    originalPrice: 8499,
    image: watch6,
    category: "Gold Collection",
    badge: "Popular",
    stock: 4,
    description: "Bold black dial with luxurious gold accents. The Executive is designed for those who lead with style.",
    features: ["Two-Tone Bracelet", "Black Sunburst Dial", "Swiss Quartz Movement", "Water Resistant 50M", "Fold-Over Clasp", "1 Year Warranty"],
  },
];
