import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import heroImage from "@/assets/hero-watch.jpg";

const HeroSection = () => {
  return (
    <section className="relative h-[90vh] min-h-[600px] overflow-hidden">
      <div className="absolute inset-0">
        <img
          src={heroImage}
          alt="Luxury timepiece by Syeds.store"
          className="w-full h-full object-cover"
          width={1920}
          height={1080}
        />
        <div className="absolute inset-0 bg-gradient-to-r from-background via-background/70 to-transparent" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-full flex items-center">
        <div className="max-w-xl animate-fade-in-up">
          <p className="text-gold font-body text-sm tracking-[0.3em] uppercase mb-4">
            Syeds.store — Premium Timepieces
          </p>
          <h1 className="font-display text-5xl sm:text-6xl lg:text-7xl font-bold leading-tight mb-6">
            Luxury That{" "}
            <span className="text-gradient-gold italic">Defines</span>{" "}
            You
          </h1>
          <p className="text-muted-foreground font-body text-lg mb-8 leading-relaxed">
            Premium Watches at Unmatched Prices. Curated for the modern gentleman who appreciates timeless elegance.
          </p>
          <div className="flex gap-4">
            <Link to="/collections">
              <Button variant="gold" size="lg" className="px-10 py-6 text-sm">
                Shop Now
              </Button>
            </Link>
            <Link to="/collections">
              <Button variant="goldOutline" size="lg" className="px-10 py-6 text-sm">
                View Collections
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
